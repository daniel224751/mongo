# Employee Management System - Backend

This is a full-stack Employee Management application with Express.js backend and MongoDB Atlas database.

## Features

- ✅ Get all employees
- ✅ Get single employee by ID
- ✅ Add new employee
- ✅ Update employee information
- ✅ Delete employee

## Prerequisites

- Node.js installed
- MongoDB Atlas account with a cluster created

## Setup Instructions

### 1. Install Dependencies

Dependencies are already installed. If needed, run:
```bash
npm install
```

### 2. Configure MongoDB Atlas Connection

1. Log in to your [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) account
2. Create a cluster (if not already created)
3. Click "Connect" on your cluster
4. Choose "Connect your application"
5. Copy the connection string
6. Open `app.js` and replace the `mongoURI` variable (line 20) with your connection string:

```javascript
const mongoURI = 'mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/employeeDB?retryWrites=true&w=majority';
```

**Important:** Replace `<username>` and `<password>` with your actual MongoDB credentials.

### 3. Start the Server

```bash
npm start
```

Or for development with auto-restart:
```bash
npm run dev
```

The server will run on `http://localhost:3000`

## API Endpoints

### 1. Get All Employees
- **Method:** GET
- **Endpoint:** `/api/employeelist`
- **Response:** Array of all employees

### 2. Get Single Employee
- **Method:** GET
- **Endpoint:** `/api/employeelist/:id`
- **Response:** Single employee object

### 3. Add New Employee
- **Method:** POST
- **Endpoint:** `/api/employeelist`
- **Request Body:**
```json
{
  "name": "John Doe",
  "location": "New York",
  "position": "Software Engineer",
  "salary": 75000
}
```

### 4. Update Employee
- **Method:** PUT
- **Endpoint:** `/api/employeelist`
- **Request Body:**
```json
{
  "_id": "employee_id_here",
  "name": "John Doe",
  "location": "San Francisco",
  "position": "Senior Software Engineer",
  "salary": 95000
}
```

### 5. Delete Employee
- **Method:** DELETE
- **Endpoint:** `/api/employeelist/:id`
- **Response:** Success message

## Database Schema

```javascript
{
  name: String (required),
  location: String (required),
  position: String (required),
  salary: Number (required),
  createdAt: Date (auto-generated),
  updatedAt: Date (auto-generated)
}
```

## Technologies Used

- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MongoDB Atlas** - Cloud database
- **Mongoose** - MongoDB ODM
- **CORS** - Cross-Origin Resource Sharing
- **Body-Parser** - Request body parsing

## Notes

- The frontend is served from the `dist/Frontend` folder
- All API routes are prefixed with `/api`
- Error handling is implemented for all endpoints
- The server uses async/await for database operations
#   m o n g o  
 #   m o n g o  
 